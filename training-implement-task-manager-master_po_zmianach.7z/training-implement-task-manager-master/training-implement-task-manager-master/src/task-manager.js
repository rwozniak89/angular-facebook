class TaskManager{
    constructor() {
        this.list = [];
    }

    getTaskList = function (){
        return this.list;
    }
    addTask = function(name, callback, context){
        const task = {
            name,
            callback,
            context
        }
        this.list.push(task);
    }

    run  = function(){
        this.list.forEach(task => task.callback.call(task.context))

        
       
    }

    clean  = function(){
        this.list.length = 0;
    }
}
