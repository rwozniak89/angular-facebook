function TaskManager(){
    this.list = [];

   
}

TaskManager.prototype.getTaskList = function (){
    return this.list;

}

TaskManager.prototype.addTask = function(name, callback, context){
    const task = {
        name: name,
        callback: callback,
        context: context
    }
    this.list.push(task);
}

TaskManager.prototype.run  = function(){
    this.list.forEach(function(task) {
        task.callback.call(task.context, 1, 2, 3, 4);
        //task.callback.apply(task.context, [1,2,3,4]);
    
    });
}

TaskManager.prototype.clean  = function(){
    this.list.length = 0;
}

//const a = new TaskManager();
//a.getTaskList();

//function getTaskList()